<?php include 'model.php';
$obj = new Model();
$editid = '';
if (isset($_GET['editid'])) {
	$editid = $_GET['editid'];
}
if (isset($_POST['update'])) {
	$obj->updateRecord($_POST);
}

?>
<style >
	.editdiv{
    display: flex;
    justify-content: center;
    max-width: 100%;
 }
</style>
<div class="editdiv">
<form action="" method="POST">
 <fieldset>
  <legend>Update student details :- </legend>
  <?php $data = $obj->editRecordById($editid);
	foreach ($data as $value) {?>
		<input type="hidden" name="id" value="<?=$value['id']?>">
		<div class="form-i"><div class="label">Roll No</div> <input type="text" name="roll_no" value="<?=$value['roll_no']?>"></div>
		<div class="form-i"><div class="label">Student Name</div> <input type="text" name="name" value="<?=$value['name']?>" disabled></div>
		<div class="form-i"><div class="label">Email</div> <input type="text" name="email" value="<?=$value['email']?>" disabled></div>
		<div class="form-i"><div class="label">Mobile</div> <input type="text" name="mobile" value="<?=$value['mobile']?>" disabled></div>
		<div class="form-i"><div class="label">Dept</div> <input type="text" name="dept" value="<?=$value['dept']?>" disabled></div>
		<div class="form-i"><div class="label">Subject</div> <input type="text" name="sub" value="<?=$value['subject']?>"></div>
		<div class="form-i"><div class="label">Mark Obtain</div> <input type="text" name="mark_obtain" value="<?=$value['mark_obtain']?>"></div>
<!-- 		<div class="form-i"><div class="label">Result</div> <input type="text" name=""></div>
		<div class="form-i"><div class="label">Grade</div> <input type="text" name=""></div> -->
		<?php } ?>
		<input type="submit" name="update" value="Update" class="submit">

</fieldset>
</form>
</div>
