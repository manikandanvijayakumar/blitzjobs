<?php include 'model.php';
$obj = new Model();

if (isset($_POST['create'])) {
	$post = $obj->insertRecord($_POST);
}

if (isset($_GET['deleteid'])) {
	$post = $obj->deleteRecord($_GET['deleteid']);
}
 ?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
<link rel="stylesheet" href="css/custom.css">
</head>
<body>
	<div>
		

<button class="btn" id="btn-modal">Add</button>

		
			
		

		<?php
			$data = $obj->displayRecord();
			foreach ($data as $value) {
		 ?>
		 <div>
		<table>
			<caption>Name: <?= $value['name']?><br>Email-id: <?= $value['email']?><br>Mobile: <?= $value['mobile']?><br>Department: <?= $value['dept']?></caption>
			<thead>
				<tr>
					<th>Roll number</th>
					
					<th>Subject</th>
					<th>Mark obtain</th>
					<th>Result</th>
					<th>Grade</th>
					<th>Action</th>
				</tr>
			</thead>
			<tbody>
				<?php 
					$reslut = $obj->displayRecordById($value['roll_no']);
					foreach ($reslut as $value) {
				 ?>
				<tr style="text-align: center;">
					<td><?= $value['roll_no']?></td>
					<td><?= $value['subject']?></td>
					<td><?= $value['mark_obtain']?></td>
					<td>
						<?php if ($value['result'] == 1) {?>
							<p style="color: green">Pass</p>
						<?php } else{?>
						<p style="color: red">Fail</p>
					<?php } ?>
					</td>
					<td>
						<?php if ($value['grade'] == 'F') {?>
							<p style="color: red"><?=$value['grade']?></p>
						<?php } else{ echo $value['grade']; } ?>
					</td>
					<td class="text-center">
						<a href="edit.php?editid=<?= $value['id']?>"><span class="edit">Edit</span></a> |
						<a href="index.php?deleteid=<?= $value['id']?>"><span class="del">Delete</span></a>
					</td>
				</tr>
			<?php } ?>
			</tbody>
		</table>
		</div>
		<?php } ?>

	</div>

<div class="overlay" id="overlay"></div>
<div class="modal" id="modal">
  <button class="modal-close-btn" id="close-btn">x</button>

			

		<form action="" method="POST">
 <fieldset>
  <legend>Add student details :- </legend>
		<div class="form-i"><div class="label">Roll No</div> <input type="text" name="roll_no" required=""></div>
		<div class="form-i"><div class="label">Student Name</div> <input type="text" name="name"></div>
		<div class="form-i"><div class="label">Email</div> <input type="text" name="email"></div>
		<div class="form-i"><div class="label">Mobile</div> <input type="text" name="mobile"></div>
		<div class="form-i"><div class="label">Dept</div> <input type="text" name="dept"></div>
		<div class="form-i"><div class="label">Subject</div> <input type="text" name="sub"></div>
		<div class="form-i"><div class="label">Mark Obtain</div> <input type="text" name="mark_obtain"></div>
<!-- 		<div class="form-i"><div class="label">Result</div> <input type="text" name=""></div>
		<div class="form-i"><div class="label">Grade</div> <input type="text" name=""></div> -->
		<input type="submit" name="create" value="Create" class="submit">

</fieldset>
</form>

</div>

</body>
<script>
	document.getElementById('btn-modal').addEventListener('click', function() {
  document.getElementById('overlay').classList.add('is-visible');
  document.getElementById('modal').classList.add('is-visible');
});

document.getElementById('close-btn').addEventListener('click', function() {
  document.getElementById('overlay').classList.remove('is-visible');
  document.getElementById('modal').classList.remove('is-visible');
});
document.getElementById('overlay').addEventListener('click', function() {
  document.getElementById('overlay').classList.remove('is-visible');
  document.getElementById('modal').classList.remove('is-visible');
});

	</script>

<script>
	document.getElementById('edit-modal').addEventListener('click', function() {
  document.getElementById('overlay').classList.add('is-visible');
  document.getElementById('modal').classList.add('is-visible');
});

document.getElementById('close-btn').addEventListener('click', function() {
  document.getElementById('overlay').classList.remove('is-visible');
  document.getElementById('modal').classList.remove('is-visible');
});
document.getElementById('overlay').addEventListener('click', function() {
  document.getElementById('overlay').classList.remove('is-visible');
  document.getElementById('modal').classList.remove('is-visible');
});

	</script>
</html>