<?php 

	class Model
	{
		Private $server = 'localhost';
		Private $user = 'root';
		Private $pass = '';
		Private $database = 'blitzjobs';
		Private $conn;
		
		function __construct()
		{
			$this->connection();
		}

		Protected function connection()
		{
			$this->conn = mysqli_connect($this->server, $this->user, $this->pass, $this->database);

			if ($this->conn->connect_error) {
				echo "Fail".$this->conn->connect_error;
			}
			else{
				return $this->conn;
			}
		}

		public function insertRecord($post)
		{
			$name = $post['name'];
			$roll_no = $post['roll_no'];
			$email = $post['email'];
			$mobile = $post['mobile'];
			$dept = $post['dept'];
			$sub = $post['sub'];
			$mark_obtain = $post['mark_obtain'];
			$total_mark = '100';
			$result = '';
			$grade = '';
			if ($mark_obtain>=50) {
				$result = '1';
			}
			else{
				$result = '0';
			}

			if ($mark_obtain>=91) {
				$grade = 'S';
			}
			elseif ($mark_obtain>=81) {
				$grade = 'A+';
			}
			elseif ($mark_obtain>=71) {
				$grade = 'A';
			}
			elseif ($mark_obtain>=61) {
				$grade = 'B';
			}
			elseif ($mark_obtain>=50) {
				$grade = 'C';
			}
			else{
				$grade = 'F';
			}

			$sql = "SELECT roll_no FROM `student` WHERE `roll_no` = '$roll_no'";
			$data = $this->conn->query($sql);

			if ($data->num_rows>0) {
				foreach ($data as $value) {
					$roll_no_old = $value['roll_no'];
					$sql = "INSERT INTO `result`(`roll_no`, `subject`, `total_mark`, `mark_obtain`, `result`, `grade`) VALUES ('$roll_no_old','$sub','$total_mark','$mark_obtain','$result','$grade')";
					$data2 = $this->conn->query($sql);
					header('location:index.php?msg=sus');
				}
			}
			else{
				$sql = "INSERT INTO `student`(`roll_no`, `name`, `email`, `mobile`, `dept`) VALUES ('$roll_no','$name','$email','$mobile','$dept')";
				$this->conn->query($sql);

				$sql2 = "INSERT INTO `result`(`roll_no`, `subject`, `total_mark`, `mark_obtain`, `result`, `grade`) VALUES ('$roll_no','$sub','$total_mark','$mark_obtain','$result','$grade')";
				$data2 = $this->conn->query($sql2);
					header('location:index.php?msg=sus');

			}
			
		}

		public function displayRecord()
		{
			$sql = "select * from student";
			return $result = $this->conn->query($sql);
		}

		public function displayRecordById($rollid)
		{
			$sql = "select * from result where roll_no = '$rollid'";
			return $result = $this->conn->query($sql);
		}

		public function editRecordById($id)
		{
			$sql = "SELECT RE.id, RE.roll_no, RE.subject, RE.mark_obtain, ST.name, ST.email, ST.mobile, ST.dept FROM result RE LEFT JOIN student ST ON ST.roll_no = RE.roll_no WHERE RE.id = '$id'";
			return $result = $this->conn->query($sql);
		}
		
		public function updateRecord($post)
		{
			$id = $post['id'];
			$roll_no = $post['roll_no'];
			$sub = $post['sub'];
			$mark_obtain = $post['mark_obtain'];
			$total_mark = '100';
			$result = '';
			$grade = '';
			if ($mark_obtain>=50) {
				$result = '1';
			}
			else{
				$result = '0';
			}

			if ($mark_obtain>=91) {
				$grade = 'S';
			}
			elseif ($mark_obtain>=81) {
				$grade = 'A+';
			}
			elseif ($mark_obtain>=71) {
				$grade = 'A';
			}
			elseif ($mark_obtain>=61) {
				$grade = 'B';
			}
			elseif ($mark_obtain>=50) {
				$grade = 'C';
			}
			else{
				$grade = 'F';
			}
			$roll_no_old = '';

			$sql = "UPDATE result SET subject='$sub',total_mark='$total_mark',mark_obtain='$mark_obtain',result='$result',grade='$grade' WHERE id = '$id'";
			$this->conn->query($sql);

			$sql2 = "SELECT roll_no FROM result WHERE id = '$id'";
			$data = $this->conn->query($sql2);

			if ($data->num_rows>0) {
				foreach ($data as $value) {
					$roll_no_old = $value['roll_no'];
				}
			}
			if ($roll_no_old != $roll_no) {
				$sql3 = "UPDATE `student` SET `roll_no`= '$roll_no' WHERE `roll_no` = '$roll_no_old'";
				$this->conn->query($sql3);
				$sql4 = "UPDATE `result` SET `roll_no`= '$roll_no' WHERE `roll_no` = '$roll_no_old'";
				$this->conn->query($sql4);
			}
			header('location:index.php?msg=sus');
		}

		public function deleteRecord($deleteid)
		{
			$sql = "DELETE FROM `result` WHERE `id`='$deleteid'";
			$data2 = $this->conn->query($sql);
			header('location:index.php?msg=sus');
		}
	}

?>